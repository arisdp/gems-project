<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>GEMS Dashboard</title>
    @vite('resources/js/app.js')
</head>

<body class="hold-transition sidebar-mini">
    <div id="app"></div>
</body>

</html>