<template>
    <footer class="main-footer text-center">
        <strong>GEMS Technical Test</strong>
    </footer>
</template>
